module Printing (showExp) where

import Data.List (intercalate)
import Exp

showVar :: Var -> String
showVar = getVar

inParens :: String -> String
inParens s = "(" ++ s ++ ")"

showExp :: ComplexExp -> String
showExp (CX x) = showVar x
showExp (Nat n) = show n
showExp (CLam x e) = inParens ("\\" ++ showVar x ++ " -> " ++ showExp e)
showExp (CApp e1 e2) = inParens (showExp e1 ++ " " ++ showExp e2)
showExp (Let x ex e) = inParens ("let " ++ showVar x ++ " := " ++ showExp ex ++ " in " ++ showExp e)
showExp (LetRec x ex e) = inParens ("letrec " ++ showVar x ++ " := " ++ showExp ex ++ " in " ++ showExp e)
showExp (List l) = "[" ++ intercalate "," (map showExp l) ++ "]"

freshVar :: Var -> Set.Set Var -> Var
freshVar x usedVars = fromMaybe x (freshVar' x 1)
  where
    freshVar' :: Var -> Int -> Maybe Var
    freshVar' v n
      | v' `Set.member` usedVars = freshVar' v (n + 1)
      | otherwise = Just v'
      where
        v' = Var (getVar v ++ show n)
